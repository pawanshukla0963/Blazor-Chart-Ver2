﻿//namespace ChartBlazorApp1.Services
//{
//    public class WeatherForecastServiceRB
//    {
//    }
//}

namespace ChartBlazorApp1.Data
{
    using ChartBlazorApp1.Data;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;


    public class WeatherForecastServiceRB
    {
        private List<WeatherForecastRB> RangeForecast { get; set; }
        // ...

        public WeatherForecastServiceRB()
        {
            RangeForecast = CreateRangeForecast();
            // ...
        }

        private List<WeatherForecastRB> CreateRangeForecast()
        {
            var rng = new Random();
            DateTime startDate = DateTime.Now.Date;
            return Enumerable.Range(1, 15).SelectMany(day => {
                var dayDate = startDate.AddDays(day);
                int avgTemp = rng.Next(-20, 55);
                int minTemp = Math.Max(-20, avgTemp - 10);
                int maxTemp = Math.Min(55, avgTemp + 10);
                return Enumerable.Range(0, 24).Select(hour => new WeatherForecastRB
                {
                    Date = dayDate.AddHours(hour),
                    TemperatureC = rng.Next(minTemp, maxTemp),
                    Precipitation = rng.Next(0, 50)
                });
            }).ToList();
        }

        public Task<WeatherForecastRB[]> GetRangeForecastAsync(CancellationToken ct = default)
        {
            return Task.FromResult(RangeForecast.ToArray());
        }
        // ...
    }
}
