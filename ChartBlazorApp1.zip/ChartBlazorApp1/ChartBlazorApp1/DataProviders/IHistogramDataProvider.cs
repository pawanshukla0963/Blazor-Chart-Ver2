using System.Collections.Generic;
using System.Threading.Tasks;
using ChartBlazorApp1.Data;

namespace ChartBlazorApp1.DataProviders {
    public interface IHistogramDataProvider {
        public Task<IEnumerable<DataPoint>> GetNormalDistribution();
        public Task<IEnumerable<DataPoint>> GenerateData();
    }
}
